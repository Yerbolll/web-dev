from django.contrib import admin
from .models import *

# Register your models here.

@admin.register(Company)
class CompanyAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'city')

@admin.register(Vacancy)
class VacancyAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'get_company_name')

    def get_company_name(self, obj):
        return obj.company.name

    get_company_name.short_description = 'Company Name'