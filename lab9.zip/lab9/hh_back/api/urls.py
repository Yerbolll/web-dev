from django.urls import path
from . import views

urlpatterns = [
    path('companies/', views.all_companies, name='company_list'),
    path('companies/<int:company_id>/', views.company, name='company'),
    path('vacancies/', views.all_vacancies, name='vacancy_list'),
    path('vacancies/<int:vacancy_id>/', views.vacancy, name='vacancy'),
    path('companies/<int:company_id>/vacancies/', views.vacancy_detail, name='vacancies_list'),
    path('vacancies/top_ten/', views.top_ten_vacancies, name='top_ten_vacancies')
]